
  # CheckWise SaaS UI Design

  This is a code bundle for CheckWise SaaS UI Design. The original project is available at https://www.figma.com/design/yTPyI8U8QJmdg0p5aA3WBF/CheckWise-SaaS-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  