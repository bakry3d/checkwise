import { ImageWithFallback } from './figma/ImageWithFallback';
import { Check, Shield, TrendingUp, Zap, Menu, X } from 'lucide-react';
import { useState } from 'react';

interface LandingPageProps {
  onNavigate: (page: string) => void;
}

export function LandingPage({ onNavigate }: LandingPageProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-gray-100">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <span className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] bg-clip-text text-transparent">
                CheckWise
              </span>
            </div>

            {/* Desktop Menu */}
            <nav className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-[#6B7280] hover:text-[#111827] transition-colors">
                كيف يعمل؟
              </a>
              <a href="#pricing" className="text-[#6B7280] hover:text-[#111827] transition-colors">
                الأسعار
              </a>
              <button
                onClick={() => onNavigate('auth')}
                className="text-[#6B7280] hover:text-[#111827] transition-colors"
              >
                تسجيل الدخول
              </button>
              <button
                onClick={() => onNavigate('auth')}
                className="px-6 py-2.5 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white rounded-2xl hover:shadow-lg hover:shadow-blue-500/30 transition-all"
              >
                ابدأ مجانًا
              </button>
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t border-gray-100">
              <nav className="flex flex-col gap-4">
                <a href="#features" className="text-[#6B7280] hover:text-[#111827] transition-colors">
                  كيف يعمل؟
                </a>
                <a href="#pricing" className="text-[#6B7280] hover:text-[#111827] transition-colors">
                  الأسعار
                </a>
                <button
                  onClick={() => onNavigate('auth')}
                  className="text-[#6B7280] hover:text-[#111827] transition-colors text-right"
                >
                  تسجيل الدخول
                </button>
                <button
                  onClick={() => onNavigate('auth')}
                  className="px-6 py-2.5 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white rounded-2xl"
                >
                  ابدأ مجانًا
                </button>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 lg:px-8 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-right">
            <h1 className="mb-6 text-[#111827]">
              افحص المنتج قبل ما تشتريه.
            </h1>
            <p className="mb-8 text-[#6B7280] max-w-xl mx-auto lg:mx-0">
              CheckWise يحلل التقييمات والإعلانات ويعطيك نسبة ثقة بالمنتج قبل ما تدفع. 
              اتخذ قرارات شراء ذكية بناءً على تحليل البيانات الحقيقية.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button
                onClick={() => onNavigate('auth')}
                className="px-8 py-4 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white rounded-2xl hover:shadow-xl hover:shadow-blue-500/30 transition-all"
              >
                جرّب الفحص الأول مجاناً
              </button>
              <button className="px-8 py-4 border-2 border-[#3B82F6] text-[#3B82F6] rounded-2xl hover:bg-[#3B82F6] hover:text-white transition-all">
                شاهد مثال
              </button>
            </div>
          </div>

          {/* Dashboard Mockup */}
          <div className="relative">
            <div className="bg-white rounded-3xl shadow-2xl p-6 border border-gray-100">
              <div className="aspect-video bg-gradient-to-br from-[#3B82F6]/10 to-[#8B5CF6]/10 rounded-2xl mb-4 flex items-center justify-center relative overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1523275335684-37898b6baf30"
                  alt="Product"
                  className="w-32 h-32 object-cover rounded-2xl"
                />
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[#6B7280]">نسبة الثقة</span>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 bg-[#16A34A]/10 text-[#16A34A] rounded-full">موثوق</span>
                    <span className="text-[#16A34A]">85%</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-[#F3F4F6] rounded-2xl">
                    <div className="flex items-center gap-2 text-[#16A34A] mb-2">
                      <Check className="w-4 h-4" />
                      <span className="text-sm">نقاط إيجابية</span>
                    </div>
                    <ul className="text-xs text-[#6B7280] space-y-1">
                      <li>تقييمات إيجابية</li>
                      <li>سعر مناسب</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-[#F3F4F6] rounded-2xl">
                    <div className="flex items-center gap-2 text-[#F59E0B] mb-2">
                      <Shield className="w-4 h-4" />
                      <span className="text-sm">ملاحظات</span>
                    </div>
                    <ul className="text-xs text-[#6B7280] space-y-1">
                      <li>بعض الشكاوى</li>
                      <li>تأخير الشحن</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="bg-[#F3F4F6] py-16 lg:py-24">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4 text-[#111827]">كيف يعمل CheckWise؟</h2>
            <p className="text-[#6B7280] max-w-2xl mx-auto">
              نستخدم الذكاء الاصطناعي لتحليل آلاف التقييمات والبيانات لنعطيك نتيجة واضحة ودقيقة
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-3xl shadow-sm hover:shadow-xl transition-all">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center mb-4">
                <Shield className="w-7 h-7 text-white" />
              </div>
              <h3 className="mb-2 text-[#111827]">تحليل التقييمات الحقيقية</h3>
              <p className="text-[#6B7280]">
                نفصل التقييمات الحقيقية من المزيفة باستخدام خوارزميات متطورة
              </p>
            </div>

            <div className="bg-white p-6 rounded-3xl shadow-sm hover:shadow-xl transition-all">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center mb-4">
                <TrendingUp className="w-7 h-7 text-white" />
              </div>
              <h3 className="mb-2 text-[#111827]">كشف الإعلانات المبالغ فيها</h3>
              <p className="text-[#6B7280]">
                نكشف المنتجات التي تستخدم إعلانات مضللة أو ادعاءات غير صحيحة
              </p>
            </div>

            <div className="bg-white p-6 rounded-3xl shadow-sm hover:shadow-xl transition-all">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center mb-4">
                <Check className="w-7 h-7 text-white" />
              </div>
              <h3 className="mb-2 text-[#111827]">نسبة ثقة واضحة</h3>
              <p className="text-[#6B7280]">
                احصل على نسبة ثقة من 0-100% مع شرح مفصل للأسباب
              </p>
            </div>

            <div className="bg-white p-6 rounded-3xl shadow-sm hover:shadow-xl transition-all">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center mb-4">
                <Zap className="w-7 h-7 text-white" />
              </div>
              <h3 className="mb-2 text-[#111827]">نظام فحوص شهري</h3>
              <p className="text-[#6B7280]">
                اختر الخطة المناسبة لك واحصل على عدد محدد من الفحوص كل شهر
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-16 lg:py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4 text-[#111827]">اختر الخطة المناسبة لك</h2>
            <p className="text-[#6B7280] max-w-2xl mx-auto">
              جميع الخطط تتضمن تحليل شامل بالذكاء الاصطناعي ونسبة ثقة دقيقة
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Basic Plan */}
            <div className="bg-white border-2 border-gray-200 rounded-3xl p-8 hover:shadow-xl transition-all">
              <div className="text-center mb-6">
                <h3 className="mb-2 text-[#111827]">Basic</h3>
                <div className="flex items-baseline justify-center gap-2">
                  <span className="text-[#111827]">3.99€</span>
                  <span className="text-[#6B7280]">/شهر</span>
                </div>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-[#16A34A]" />
                  <span className="text-[#6B7280]">10 فحوص شهرياً</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-[#16A34A]" />
                  <span className="text-[#6B7280]">تحليل بالذكاء الاصطناعي</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-[#16A34A]" />
                  <span className="text-[#6B7280]">دعم البريد الإلكتروني</span>
                </li>
              </ul>
              <button
                onClick={() => onNavigate('auth')}
                className="w-full px-6 py-3 border-2 border-[#3B82F6] text-[#3B82F6] rounded-2xl hover:bg-[#3B82F6] hover:text-white transition-all"
              >
                ابدأ الآن
              </button>
            </div>

            {/* Standard Plan */}
            <div className="bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] rounded-3xl p-8 text-white relative hover:shadow-2xl hover:shadow-blue-500/30 transition-all transform hover:-translate-y-1">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-[#F59E0B] text-white px-4 py-1 rounded-full text-sm">
                الأكثر شيوعًا
              </div>
              <div className="text-center mb-6">
                <h3 className="mb-2">Standard</h3>
                <div className="flex items-baseline justify-center gap-2">
                  <span>6.99€</span>
                  <span className="opacity-80">/شهر</span>
                </div>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5" />
                  <span>30 فحص شهرياً</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5" />
                  <span>تحليل متقدم بالذكاء الاصطناعي</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5" />
                  <span>بدائل مقترحة</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5" />
                  <span>دعم ذو أولوية</span>
                </li>
              </ul>
              <button
                onClick={() => onNavigate('auth')}
                className="w-full px-6 py-3 bg-white text-[#3B82F6] rounded-2xl hover:shadow-lg transition-all"
              >
                ابدأ الآن
              </button>
            </div>

            {/* Pro Plan */}
            <div className="bg-white border-2 border-gray-200 rounded-3xl p-8 hover:shadow-xl transition-all">
              <div className="text-center mb-6">
                <h3 className="mb-2 text-[#111827]">Pro</h3>
                <div className="flex items-baseline justify-center gap-2">
                  <span className="text-[#111827]">12.99€</span>
                  <span className="text-[#6B7280]">/شهر</span>
                </div>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-[#16A34A]" />
                  <span className="text-[#6B7280]">100 فحص شهرياً</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-[#16A34A]" />
                  <span className="text-[#6B7280]">تحليل احترافي شامل</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-[#16A34A]" />
                  <span className="text-[#6B7280]">بدائل متعددة</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-[#16A34A]" />
                  <span className="text-[#6B7280]">دعم فوري 24/7</span>
                </li>
              </ul>
              <button
                onClick={() => onNavigate('auth')}
                className="w-full px-6 py-3 border-2 border-[#3B82F6] text-[#3B82F6] rounded-2xl hover:bg-[#3B82F6] hover:text-white transition-all"
              >
                ابدأ الآن
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#111827] text-white py-12">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <span className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] bg-clip-text text-transparent">
                  CheckWise
                </span>
              </div>
              <p className="text-gray-400">
                افحص المنتج قبل الشراء بثقة
              </p>
            </div>
            <div>
              <h4 className="mb-4">الشركة</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">من نحن</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">كيف يعمل</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">الأسعار</a></li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4">الدعم</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">مركز المساعدة</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">اتصل بنا</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">الأسئلة الشائعة</a></li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4">قانوني</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">الشروط والأحكام</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">سياسة الخصوصية</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">ملفات تعريف الارتباط</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>© 2025 CheckWise. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
