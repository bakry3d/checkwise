import { Sidebar } from './ui-components/sidebar';
import { Link2, ChevronDown, Info } from 'lucide-react';
import { useState } from 'react';
import { LoadingCheck } from './ui-components/loading-check';
import { toast } from 'sonner';

interface NewCheckProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
  isMobile: boolean;
}

export function NewCheck({ onNavigate, onLogout, isMobile }: NewCheckProps) {
  const [url, setUrl] = useState('');
  const [platform, setPlatform] = useState('Amazon');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url) {
      toast.error('الرجاء إدخال رابط المنتج');
      return;
    }

    setIsLoading(true);
    toast.success('تم بدء فحص المنتج!');
  };

  const handleLoadingComplete = () => {
    setIsLoading(false);
    toast.success('تم الفحص بنجاح! ✅');
    onNavigate('check-result');
  };

  const content = (
    <div className={`${isMobile ? 'pt-16 pb-20' : ''} min-h-screen flex items-center justify-center p-4`} dir="rtl">
      {isLoading && <LoadingCheck onComplete={handleLoadingComplete} />}
      
      <div className="w-full max-w-2xl">
        <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-[#111827] mb-2">فحص منتج جديد</h1>
            <p className="text-[#6B7280]">
              الصق رابط المنتج واحصل على تحليل شامل بالذكاء الاصطناعي
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* URL Input */}
            <div>
              <label htmlFor="url" className="block text-[#111827] mb-3">
                رابط المنتج
              </label>
              <div className="relative">
                <Link2 className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
                <input
                  type="url"
                  id="url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://www.amazon.com/product/..."
                  className="w-full pr-12 pl-4 py-4 border-2 border-gray-200 rounded-2xl focus:border-[#3B82F6] focus:outline-none transition-colors text-right"
                  required
                />
              </div>
            </div>

            {/* Platform Select */}
            <div>
              <label htmlFor="platform" className="block text-[#111827] mb-3">
                نوع الموقع
              </label>
              <div className="relative">
                <select
                  id="platform"
                  value={platform}
                  onChange={(e) => setPlatform(e.target.value)}
                  className="w-full px-4 py-4 pr-4 pl-12 border-2 border-gray-200 rounded-2xl focus:border-[#3B82F6] focus:outline-none transition-colors appearance-none text-right bg-white"
                >
                  <option value="Amazon">Amazon</option>
                  <option value="Temu">Temu</option>
                  <option value="TikTok Shop">TikTok Shop</option>
                  <option value="AliExpress">AliExpress</option>
                  <option value="Other">Other</option>
                </select>
                <ChevronDown className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280] pointer-events-none" />
              </div>
            </div>

            {/* Info Message */}
            <div className="bg-[#3B82F6]/10 rounded-2xl p-4 flex gap-3">
              <Info className="w-5 h-5 text-[#3B82F6] flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-[#3B82F6]">
                  سيتم خصم 1 فحص من رصيدك عند إتمام هذا الفحص.
                </p>
              </div>
            </div>

            {/* Credits Display */}
            <div className="bg-[#F3F4F6] rounded-2xl p-4 flex items-center justify-between">
              <span className="text-[#6B7280]">الرصيد المتبقي</span>
              <span className="text-[#111827]">18 / 30 فحص</span>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full px-8 py-4 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white rounded-2xl hover:shadow-xl hover:shadow-blue-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={!url}
            >
              افحص المنتج الآن
            </button>

            {/* Back Button */}
            <button
              type="button"
              onClick={() => onNavigate('dashboard')}
              className="w-full px-8 py-4 border-2 border-gray-200 text-[#6B7280] rounded-2xl hover:bg-[#F3F4F6] transition-all"
            >
              العودة إلى الرئيسية
            </button>
          </form>
        </div>

        {/* Examples */}
        <div className="mt-8 text-center">
          <p className="text-[#6B7280] mb-4">أمثلة على المنصات المدعومة:</p>
          <div className="flex flex-wrap justify-center gap-3">
            <span className="px-4 py-2 bg-white rounded-full text-[#6B7280] shadow-sm">Amazon</span>
            <span className="px-4 py-2 bg-white rounded-full text-[#6B7280] shadow-sm">Temu</span>
            <span className="px-4 py-2 bg-white rounded-full text-[#6B7280] shadow-sm">TikTok Shop</span>
            <span className="px-4 py-2 bg-white rounded-full text-[#6B7280] shadow-sm">AliExpress</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[#F3F4F6]">
      <Sidebar
        currentPage="new-check"
        onNavigate={onNavigate}
        onLogout={onLogout}
        isMobile={isMobile}
      />
      <div className="flex-1 overflow-auto">
        {content}
      </div>
    </div>
  );
}