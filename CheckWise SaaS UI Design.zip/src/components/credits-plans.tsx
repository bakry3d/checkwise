import { Sidebar } from './ui-components/sidebar';
import { Check, Zap, Calendar } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface CreditsPlansProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
  isMobile: boolean;
}

export function CreditsPlans({ onNavigate, onLogout, isMobile }: CreditsPlansProps) {
  
  const handleSelectPlan = (plan: string) => {
    toast.success(`تم اختيار خطة ${plan} بنجاح! 🎉`);
  };

  const handleBuyCredits = (amount: number, price: string) => {
    toast.success(`تمت إضافة ${amount} فحص لرصيدك! 💳`);
  };

  const content = (
    <div className={`${isMobile ? 'pt-16 pb-20' : ''} p-4 lg:p-8`} dir="rtl">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-[#111827] mb-2">الرصيد والخطط</h1>
          <p className="text-[#6B7280]">إدارة اشتراكك والحصول على فحوص إضافية</p>
        </div>

        {/* Current Plan Card */}
        <div className="bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] rounded-3xl p-6 lg:p-8 text-white mb-8">
          <div className="grid md:grid-cols-2 gap-6 items-center">
            <div>
              <p className="opacity-90 mb-2">الخطة الحالية</p>
              <h2 className="mb-6">Standard</h2>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Check className="w-5 h-5" />
                  <span>30 فحص شهرياً</span>
                </div>
                <div className="flex items-center gap-3">
                  <Check className="w-5 h-5" />
                  <span>تحليل متقدم بالذكاء الاصطناعي</span>
                </div>
                <div className="flex items-center gap-3">
                  <Check className="w-5 h-5" />
                  <span>بدائل مقترحة</span>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-4">
                <Zap className="w-5 h-5" />
                <span>الرصيد المتبقي</span>
              </div>
              <div className="mb-4">
                <div className="flex items-baseline gap-2 mb-2">
                  <span className="text-4xl">18</span>
                  <span className="opacity-90">/ 30 فحص</span>
                </div>
                <div className="bg-white/20 rounded-full h-3 overflow-hidden">
                  <div className="bg-white h-full rounded-full" style={{ width: '60%' }} />
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm opacity-90">
                <Calendar className="w-4 h-4" />
                <span>يتجدد الرصيد بعد 5 أيام</span>
              </div>
            </div>
          </div>
        </div>

        {/* Plans Section */}
        <div className="mb-8">
          <h2 className="text-[#111827] mb-6">اختر خطة جديدة</h2>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Basic Plan */}
            <div className="bg-white rounded-3xl shadow-sm border-2 border-gray-200 p-6 hover:shadow-xl transition-all">
              <div className="mb-6">
                <h3 className="text-[#111827] mb-2">Basic</h3>
                <div className="flex items-baseline gap-2 mb-4">
                  <span className="text-[#111827]">3.99€</span>
                  <span className="text-[#6B7280]">/شهر</span>
                </div>
                <p className="text-[#6B7280]">للمستخدمين العاديين</p>
              </div>

              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-[#16A34A]/10 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-[#16A34A]" />
                  </div>
                  <span className="text-[#6B7280]">10 فحوص شهرياً</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-[#16A34A]/10 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-[#16A34A]" />
                  </div>
                  <span className="text-[#6B7280]">تحليل بالذكاء الاصطناعي</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-[#16A34A]/10 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-[#16A34A]" />
                  </div>
                  <span className="text-[#6B7280]">دعم البريد الإلكتروني</span>
                </li>
              </ul>

              <button 
                onClick={() => handleSelectPlan('Basic')}
                className="w-full px-6 py-3 border-2 border-[#3B82F6] text-[#3B82F6] rounded-2xl hover:bg-[#3B82F6] hover:text-white transition-all">
                اختيار الخطة
              </button>
            </div>

            {/* Standard Plan */}
            <div className="bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] rounded-3xl p-6 text-white relative shadow-xl hover:shadow-2xl hover:shadow-blue-500/30 transition-all transform hover:-translate-y-1">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-[#F59E0B] text-white px-4 py-1 rounded-full text-sm">
                الأكثر شيوعًا
              </div>

              <div className="mb-6">
                <h3 className="mb-2">Standard</h3>
                <div className="flex items-baseline gap-2 mb-4">
                  <span>6.99€</span>
                  <span className="opacity-90">/شهر</span>
                </div>
                <p className="opacity-90">للمتسوقين المتكررين</p>
              </div>

              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>30 فحص شهرياً</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>تحليل متقدم</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>بدائل مقترحة</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>دعم ذو أولوية</span>
                </li>
              </ul>

              <button className="w-full px-6 py-3 bg-white text-[#3B82F6] rounded-2xl hover:shadow-lg transition-all">
                الخطة الحالية
              </button>
            </div>

            {/* Pro Plan */}
            <div className="bg-white rounded-3xl shadow-sm border-2 border-gray-200 p-6 hover:shadow-xl transition-all">
              <div className="mb-6">
                <h3 className="text-[#111827] mb-2">Pro</h3>
                <div className="flex items-baseline gap-2 mb-4">
                  <span className="text-[#111827]">12.99€</span>
                  <span className="text-[#6B7280]">/شهر</span>
                </div>
                <p className="text-[#6B7280]">للتجار والمحترفين</p>
              </div>

              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-[#16A34A]/10 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-[#16A34A]" />
                  </div>
                  <span className="text-[#6B7280]">100 فحص شهرياً</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-[#16A34A]/10 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-[#16A34A]" />
                  </div>
                  <span className="text-[#6B7280]">تحليل احترافي شامل</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-[#16A34A]/10 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-[#16A34A]" />
                  </div>
                  <span className="text-[#6B7280]">بدائل متعددة</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-[#16A34A]/10 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-[#16A34A]" />
                  </div>
                  <span className="text-[#6B7280]">دعم فوري 24/7</span>
                </li>
              </ul>

              <button 
                onClick={() => handleSelectPlan('Pro')}
                className="w-full px-6 py-3 border-2 border-[#3B82F6] text-[#3B82F6] rounded-2xl hover:bg-[#3B82F6] hover:text-white transition-all">
                اختيار الخطة
              </button>
            </div>
          </div>
        </div>

        {/* Additional Credits */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 lg:p-8">
          <h2 className="text-[#111827] mb-6">اشترِ فحوص إضافية</h2>
          <p className="text-[#6B7280] mb-6">
            احصل على فحوص إضافية بدون تغيير خطتك الحالية
          </p>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="border-2 border-gray-200 rounded-2xl p-6 hover:border-[#3B82F6] transition-all cursor-pointer">
              <div className="text-center mb-4">
                <span className="text-[#111827] block mb-1">10 فحوص</span>
                <span className="text-[#6B7280]">2.99€</span>
              </div>
              <button 
                onClick={() => handleBuyCredits(10, '2.99€')}
                className="w-full px-4 py-2 bg-[#F3F4F6] text-[#111827] rounded-xl hover:bg-[#3B82F6] hover:text-white transition-all">
                شراء
              </button>
            </div>

            <div className="border-2 border-[#3B82F6] rounded-2xl p-6 bg-[#3B82F6]/5 relative">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#16A34A] text-white px-3 py-1 rounded-full text-xs">
                الأفضل
              </div>
              <div className="text-center mb-4">
                <span className="text-[#111827] block mb-1">20 فحص</span>
                <span className="text-[#6B7280]">4.99€</span>
              </div>
              <button 
                onClick={() => handleBuyCredits(20, '4.99€')}
                className="w-full px-4 py-2 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white rounded-xl hover:shadow-lg transition-all">
                شراء
              </button>
            </div>

            <div className="border-2 border-gray-200 rounded-2xl p-6 hover:border-[#3B82F6] transition-all cursor-pointer">
              <div className="text-center mb-4">
                <span className="text-[#111827] block mb-1">50 فحص</span>
                <span className="text-[#6B7280]">9.99€</span>
              </div>
              <button 
                onClick={() => handleBuyCredits(50, '9.99€')}
                className="w-full px-4 py-2 bg-[#F3F4F6] text-[#111827] rounded-xl hover:bg-[#3B82F6] hover:text-white transition-all">
                شراء
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[#F3F4F6]">
      <Sidebar
        currentPage="credits"
        onNavigate={onNavigate}
        onLogout={onLogout}
        isMobile={isMobile}
      />
      <div className="flex-1 overflow-auto">
        {content}
      </div>
    </div>
  );
}