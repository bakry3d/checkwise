import { Home, Search, History, CreditCard, Settings, LogOut, Shield, Menu, X } from 'lucide-react';
import { useState } from 'react';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onLogout: () => void;
  isMobile?: boolean;
}

export function Sidebar({ currentPage, onNavigate, onLogout, isMobile }: SidebarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const menuItems = [
    { id: 'dashboard', label: 'الرئيسية', icon: Home },
    { id: 'new-check', label: 'فحص منتج جديد', icon: Search },
    { id: 'history', label: 'السجل', icon: History },
    { id: 'credits', label: 'الرصيد والخطط', icon: CreditCard },
    { id: 'settings', label: 'الإعدادات', icon: Settings },
  ];

  const handleNavigate = (page: string) => {
    onNavigate(page);
    if (isMobile) {
      setIsOpen(false);
    }
  };

  if (isMobile) {
    return (
      <>
        {/* Mobile Header */}
        <div className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200 px-4 py-3" dir="rtl">
          <div className="flex items-center justify-between">
            <button onClick={() => setIsOpen(!isOpen)} className="p-2">
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <span className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] bg-clip-text text-transparent">
                CheckWise
              </span>
            </div>
          </div>
        </div>

        {/* Mobile Menu Overlay */}
        {isOpen && (
          <div className="fixed inset-0 z-40 bg-black/50" onClick={() => setIsOpen(false)} />
        )}

        {/* Mobile Menu */}
        <div
          className={`fixed top-0 right-0 bottom-0 z-50 w-80 bg-white shadow-2xl transform transition-transform duration-300 ${
            isOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
          dir="rtl"
        >
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <span className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] bg-clip-text text-transparent">
                CheckWise
              </span>
            </div>
            <p className="text-[#6B7280]">أهلاً، Bakri 👋</p>
          </div>

          <nav className="p-4">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavigate(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl mb-2 transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white shadow-lg'
                      : 'text-[#6B7280] hover:bg-[#F3F4F6]'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200">
            <button
              onClick={onLogout}
              className="w-full flex items-center gap-3 px-4 py-3 text-[#DC2626] hover:bg-red-50 rounded-2xl transition-all"
            >
              <LogOut className="w-5 h-5" />
              <span>تسجيل الخروج</span>
            </button>
          </div>
        </div>
      </>
    );
  }

  // Desktop Sidebar
  return (
    <div className="w-72 bg-white border-l border-gray-200 h-screen sticky top-0 flex flex-col" dir="rtl">
      {/* Logo */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <span className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] bg-clip-text text-transparent">
            CheckWise
          </span>
        </div>
        <p className="text-[#6B7280]">أهلاً، Bakri 👋</p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl mb-2 transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white shadow-lg'
                  : 'text-[#6B7280] hover:bg-[#F3F4F6]'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-gray-200">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 text-[#DC2626] hover:bg-red-50 rounded-2xl transition-all"
        >
          <LogOut className="w-5 h-5" />
          <span>تسجيل الخروج</span>
        </button>
      </div>
    </div>
  );
}
