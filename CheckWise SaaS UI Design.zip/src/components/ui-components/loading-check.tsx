import { Loader2, Search, Shield, TrendingUp } from 'lucide-react';
import { useEffect, useState } from 'react';

interface LoadingCheckProps {
  onComplete: () => void;
}

export function LoadingCheck({ onComplete }: LoadingCheckProps) {
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    { icon: Search, label: 'جاري تحليل رابط المنتج...', progress: 20 },
    { icon: Shield, label: 'فحص التقييمات والمراجعات...', progress: 45 },
    { icon: TrendingUp, label: 'تحليل البيانات بالذكاء الاصطناعي...', progress: 70 },
    { icon: Shield, label: 'حساب نسبة الثقة...', progress: 90 },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 500);
          return 100;
        }
        return prev + 1;
      });
    }, 40);

    return () => clearInterval(timer);
  }, [onComplete]);

  useEffect(() => {
    const step = steps.findIndex((s) => progress < s.progress);
    setCurrentStep(step === -1 ? steps.length - 1 : Math.max(0, step));
  }, [progress]);

  const CurrentIcon = steps[currentStep].icon;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-3xl p-8 lg:p-12 max-w-md w-full">
        {/* Animated Icon */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center animate-pulse">
              <CurrentIcon className="w-12 h-12 text-white" />
            </div>
            <div className="absolute inset-0 rounded-full border-4 border-[#3B82F6]/20 animate-ping" />
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[#6B7280]">جاري الفحص...</span>
            <span className="text-[#3B82F6]">{progress}%</span>
          </div>
          <div className="bg-[#F3F4F6] rounded-full h-3 overflow-hidden">
            <div
              className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] h-full rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Current Step */}
        <div className="text-center">
          <p className="text-[#111827] flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin" />
            {steps[currentStep].label}
          </p>
        </div>

        {/* Steps Indicators */}
        <div className="flex justify-center gap-2 mt-8">
          {steps.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full transition-all ${
                index <= currentStep ? 'bg-[#3B82F6]' : 'bg-gray-300'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
