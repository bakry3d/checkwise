import { LucideIcon } from 'lucide-react';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export function EmptyState({ icon: Icon, title, description, actionLabel, onAction }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4" dir="rtl">
      <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#3B82F6]/10 to-[#8B5CF6]/10 flex items-center justify-center mb-6">
        <Icon className="w-12 h-12 text-[#3B82F6]" />
      </div>
      <h3 className="text-[#111827] mb-2 text-center">{title}</h3>
      <p className="text-[#6B7280] text-center max-w-md mb-6">{description}</p>
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="px-6 py-3 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white rounded-2xl hover:shadow-lg hover:shadow-blue-500/30 transition-all"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}
