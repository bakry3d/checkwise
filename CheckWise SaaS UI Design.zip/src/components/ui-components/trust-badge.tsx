interface TrustBadgeProps {
  score: number;
  size?: 'sm' | 'md' | 'lg';
}

export function TrustBadge({ score, size = 'md' }: TrustBadgeProps) {
  const getColor = () => {
    if (score >= 70) return { bg: 'bg-[#16A34A]/10', text: 'text-[#16A34A]', label: 'موثوق' };
    if (score >= 40) return { bg: 'bg-[#F59E0B]/10', text: 'text-[#F59E0B]', label: 'تحذير' };
    return { bg: 'bg-[#DC2626]/10', text: 'text-[#DC2626]', label: 'غير موثوق' };
  };

  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return 'px-2 py-1 text-xs';
      case 'lg':
        return 'px-6 py-3';
      default:
        return 'px-3 py-1.5';
    }
  };

  const color = getColor();

  return (
    <span className={`${color.bg} ${color.text} ${getSizeClasses()} rounded-full inline-flex items-center gap-2`}>
      <span>{color.label}</span>
      <span>{score}%</span>
    </span>
  );
}
