import { Sidebar } from './ui-components/sidebar';
import { TrustBadge } from './ui-components/trust-badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Search, TrendingUp, AlertTriangle } from 'lucide-react';

interface DashboardProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
  isMobile: boolean;
}

export function Dashboard({ onNavigate, onLogout, isMobile }: DashboardProps) {
  const recentChecks = [
    {
      id: 1,
      date: '2025-11-14',
      name: 'ساعة ذكية رياضية مقاومة للماء',
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30',
      platform: 'Amazon',
      score: 85,
      status: 'موثوق',
    },
    {
      id: 2,
      date: '2025-11-13',
      name: 'سماعات بلوتوث لاسلكية',
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',
      platform: 'TikTok Shop',
      score: 45,
      status: 'تحذير',
    },
    {
      id: 3,
      date: '2025-11-12',
      name: 'كاميرا أمان منزلية ذكية',
      image: 'https://images.unsplash.com/photo-1558002038-1055907df827',
      platform: 'AliExpress',
      score: 72,
      status: 'موثوق',
    },
    {
      id: 4,
      date: '2025-11-11',
      name: 'حقيبة ظهر للسفر',
      image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62',
      platform: 'Temu',
      score: 25,
      status: 'غير موثوق',
    },
  ];

  const content = (
    <div className={`${isMobile ? 'pt-16 pb-20' : ''} p-4 lg:p-8`} dir="rtl">
      {/* Welcome Message */}
      <div className="mb-8">
        <h1 className="text-[#111827] mb-2">أهلاً، Bakri 👋</h1>
        <p className="text-[#6B7280]">مرحباً بك في لوحة التحكم</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6 mb-8">
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center">
              <Search className="w-6 h-6 text-white" />
            </div>
          </div>
          <p className="text-[#6B7280] mb-2">الرصيد المتبقي</p>
          <div className="flex items-baseline gap-2">
            <span className="text-[#111827]">18</span>
            <span className="text-[#6B7280]">/ 30 فحص</span>
          </div>
          <div className="mt-4 bg-[#F3F4F6] rounded-full h-2 overflow-hidden">
            <div className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] h-full" style={{ width: '60%' }} />
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-2xl bg-[#16A34A]/10 flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-[#16A34A]" />
            </div>
          </div>
          <p className="text-[#6B7280] mb-2">عدد الفحوص هذا الشهر</p>
          <span className="text-[#111827]">22</span>
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-2xl bg-[#DC2626]/10 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-[#DC2626]" />
            </div>
          </div>
          <p className="text-[#6B7280] mb-2">منتجات مشكوك فيها</p>
          <span className="text-[#111827]">5</span>
        </div>
      </div>

      {/* New Check Button */}
      <div className="mb-8">
        <button
          onClick={() => onNavigate('new-check')}
          className="w-full md:w-auto px-8 py-4 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white rounded-2xl hover:shadow-xl hover:shadow-blue-500/30 transition-all flex items-center justify-center gap-3"
        >
          <Search className="w-5 h-5" />
          <span>فحص منتج جديد</span>
        </button>
      </div>

      {/* Recent Checks Table */}
      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-[#111827]">آخر الفحوص</h2>
        </div>

        {/* Mobile View */}
        {isMobile ? (
          <div className="divide-y divide-gray-100">
            {recentChecks.map((check) => (
              <div key={check.id} className="p-4">
                <div className="flex gap-4 mb-3">
                  <ImageWithFallback
                    src={check.image}
                    alt={check.name}
                    className="w-16 h-16 rounded-2xl object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="text-[#111827] mb-1">{check.name}</h3>
                    <p className="text-[#6B7280]">{check.platform}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#6B7280]">{check.date}</span>
                  <TrustBadge score={check.score} size="sm" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Desktop Table */
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#F3F4F6]">
                <tr>
                  <th className="px-6 py-4 text-right text-[#6B7280]">التاريخ</th>
                  <th className="px-6 py-4 text-right text-[#6B7280]">المنتج</th>
                  <th className="px-6 py-4 text-right text-[#6B7280]">الموقع</th>
                  <th className="px-6 py-4 text-right text-[#6B7280]">نسبة الثقة</th>
                  <th className="px-6 py-4 text-right text-[#6B7280]">النتيجة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {recentChecks.map((check) => (
                  <tr key={check.id} className="hover:bg-[#F3F4F6]/50 transition-colors cursor-pointer" onClick={() => onNavigate('check-result')}>
                    <td className="px-6 py-4 text-[#6B7280]">{check.date}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <ImageWithFallback
                          src={check.image}
                          alt={check.name}
                          className="w-12 h-12 rounded-xl object-cover"
                        />
                        <span className="text-[#111827]">{check.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-[#6B7280]">{check.platform}</td>
                    <td className="px-6 py-4">
                      <TrustBadge score={check.score} size="sm" />
                    </td>
                    <td className="px-6 py-4">
                      <span className={`
                        ${check.score >= 70 ? 'text-[#16A34A]' : ''}
                        ${check.score >= 40 && check.score < 70 ? 'text-[#F59E0B]' : ''}
                        ${check.score < 40 ? 'text-[#DC2626]' : ''}
                      `}>
                        {check.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[#F3F4F6]">
      <Sidebar
        currentPage="dashboard"
        onNavigate={onNavigate}
        onLogout={onLogout}
        isMobile={isMobile}
      />
      <div className="flex-1 overflow-auto">
        {content}
      </div>
    </div>
  );
}
