import { Sidebar } from './ui-components/sidebar';
import { TrustBadge } from './ui-components/trust-badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { EmptyState } from './ui-components/empty-state';
import { Search, Filter, History as HistoryIcon } from 'lucide-react';
import { useState } from 'react';

interface HistoryProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
  isMobile: boolean;
}

export function History({ onNavigate, onLogout, isMobile }: HistoryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showEmpty, setShowEmpty] = useState(false); // Change to true to see empty state

  const checks = [
    {
      id: 1,
      date: '2025-11-14',
      name: 'ساعة ذكية رياضية مقاومة للماء',
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30',
      platform: 'Amazon',
      score: 85,
      status: 'موثوق',
    },
    {
      id: 2,
      date: '2025-11-13',
      name: 'سماعات بلوتوث لاسلكية عالية الجودة',
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',
      platform: 'TikTok Shop',
      score: 45,
      status: 'تحذير',
    },
    {
      id: 3,
      date: '2025-11-12',
      name: 'كاميرا أمان منزلية ذكية مع رؤية ليلية',
      image: 'https://images.unsplash.com/photo-1558002038-1055907df827',
      platform: 'AliExpress',
      score: 72,
      status: 'موثوق',
    },
    {
      id: 4,
      date: '2025-11-11',
      name: 'حقيبة ظهر للسفر متعددة الجيوب',
      image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62',
      platform: 'Temu',
      score: 25,
      status: 'غير موثوق',
    },
    {
      id: 5,
      date: '2025-11-10',
      name: 'شاحن لاسلكي سريع للهواتف الذكية',
      image: 'https://images.unsplash.com/photo-1591290619762-c588f8f2cc78',
      platform: 'Amazon',
      score: 78,
      status: 'موثوق',
    },
    {
      id: 6,
      date: '2025-11-09',
      name: 'مصباح LED ذكي قابل للتحكم عن بعد',
      image: 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15',
      platform: 'TikTok Shop',
      score: 35,
      status: 'غير موثوق',
    },
  ];

  const content = (
    <div className={`${isMobile ? 'pt-16 pb-20' : ''} p-4 lg:p-8`} dir="rtl">
      <div className="mb-8">
        <h1 className="text-[#111827] mb-2">سجل الفحوص</h1>
        <p className="text-[#6B7280]">جميع فحوصات المنتجات التي قمت بها</p>
      </div>

      {!showEmpty && (
        <>
          {/* Search & Filter */}
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-4 mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث عن منتج..."
                  className="w-full pr-12 pl-4 py-3 border-2 border-gray-200 rounded-2xl focus:border-[#3B82F6] focus:outline-none transition-colors text-right"
                />
              </div>
              <button className="px-6 py-3 border-2 border-gray-200 rounded-2xl hover:bg-[#F3F4F6] transition-all flex items-center justify-center gap-2">
                <Filter className="w-5 h-5 text-[#6B7280]" />
                <span className="text-[#6B7280]">تصفية</span>
              </button>
            </div>
          </div>

          {/* Checks Table */}
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
            {/* Mobile View */}
            {isMobile ? (
              <div className="divide-y divide-gray-100">
                {checks.map((check) => (
                  <div
                    key={check.id}
                    className="p-4 hover:bg-[#F3F4F6]/50 transition-colors cursor-pointer"
                    onClick={() => onNavigate('check-result')}
                  >
                    <div className="flex gap-4 mb-3">
                      <ImageWithFallback
                        src={check.image}
                        alt={check.name}
                        className="w-20 h-20 rounded-2xl object-cover flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="text-[#111827] mb-1 line-clamp-2">{check.name}</h3>
                        <p className="text-[#6B7280] mb-2">{check.platform}</p>
                        <TrustBadge score={check.score} size="sm" />
                      </div>
                    </div>
                    <div className="text-[#6B7280] text-right">{check.date}</div>
                  </div>
                ))}
              </div>
            ) : (
              /* Desktop Table */
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#F3F4F6]">
                    <tr>
                      <th className="px-6 py-4 text-right text-[#6B7280]">التاريخ</th>
                      <th className="px-6 py-4 text-right text-[#6B7280]">اسم المنتج</th>
                      <th className="px-6 py-4 text-right text-[#6B7280]">الموقع</th>
                      <th className="px-6 py-4 text-right text-[#6B7280]">نسبة الثقة</th>
                      <th className="px-6 py-4 text-right text-[#6B7280]">الحالة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {checks.map((check) => (
                      <tr
                        key={check.id}
                        className="hover:bg-[#F3F4F6]/50 transition-colors cursor-pointer"
                        onClick={() => onNavigate('check-result')}
                      >
                        <td className="px-6 py-4 text-[#6B7280]">{check.date}</td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <ImageWithFallback
                              src={check.image}
                              alt={check.name}
                              className="w-12 h-12 rounded-xl object-cover"
                            />
                            <span className="text-[#111827]">{check.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-[#6B7280]">{check.platform}</td>
                        <td className="px-6 py-4">
                          <TrustBadge score={check.score} size="sm" />
                        </td>
                        <td className="px-6 py-4">
                          <span
                            className={`
                            ${check.score >= 70 ? 'text-[#16A34A]' : ''}
                            ${check.score >= 40 && check.score < 70 ? 'text-[#F59E0B]' : ''}
                            ${check.score < 40 ? 'text-[#DC2626]' : ''}
                          `}
                          >
                            {check.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      {/* Empty State */}
      {showEmpty && (
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100">
          <EmptyState
            icon={HistoryIcon}
            title="لا توجد فحوص بعد"
            description="ابدأ بفحص أول منتج لك للحصول على تحليل شامل ونسبة ثقة دقيقة قبل الشراء"
            actionLabel="فحص منتج جديد"
            onAction={() => onNavigate('new-check')}
          />
        </div>
      )}
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[#F3F4F6]">
      <Sidebar
        currentPage="history"
        onNavigate={onNavigate}
        onLogout={onLogout}
        isMobile={isMobile}
      />
      <div className="flex-1 overflow-auto">
        {content}
      </div>
    </div>
  );
}