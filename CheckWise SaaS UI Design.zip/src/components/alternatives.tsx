import { Sidebar } from './ui-components/sidebar';
import { TrustBadge } from './ui-components/trust-badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ArrowRight, TrendingUp, DollarSign, Star, ShoppingBag } from 'lucide-react';

interface AlternativesProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
  isMobile: boolean;
}

export function Alternatives({ onNavigate, onLogout, isMobile }: AlternativesProps) {
  const originalProduct = {
    name: 'ساعة ذكية رياضية مقاومة للماء',
    price: '29.99€',
    score: 82,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30',
    platform: 'Amazon',
  };

  const alternatives = [
    {
      id: 1,
      name: 'ساعة ذكية Xiaomi Mi Band 7 Pro',
      price: '34.99€',
      originalPrice: '49.99€',
      score: 92,
      image: 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a',
      platform: 'Amazon',
      rating: 4.8,
      reviews: 12450,
      highlights: ['بطارية تدوم 14 يوم', 'شاشة AMOLED كبيرة', 'GPS مدمج'],
      savings: '15€',
    },
    {
      id: 2,
      name: 'ساعة Amazfit GTR 4',
      price: '39.99€',
      originalPrice: '59.99€',
      score: 88,
      image: 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1',
      platform: 'Amazon',
      rating: 4.6,
      reviews: 8320,
      highlights: ['تصميم أنيق', '150+ نمط رياضي', 'دقة عالية في القياسات'],
      savings: '20€',
    },
    {
      id: 3,
      name: 'ساعة Fitbit Charge 5',
      price: '44.99€',
      originalPrice: '69.99€',
      score: 90,
      image: 'https://images.unsplash.com/photo-1557438159-51eec7a6c9e8',
      platform: 'Amazon',
      rating: 4.7,
      reviews: 15680,
      highlights: ['مستشعر ECG', 'متابعة النوم المتقدمة', 'علامة تجارية موثوقة'],
      savings: '25€',
    },
  ];

  const content = (
    <div className={`${isMobile ? 'pt-16 pb-20' : ''} p-4 lg:p-8`} dir="rtl">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => onNavigate('check-result')}
            className="flex items-center gap-2 text-[#3B82F6] hover:text-[#8B5CF6] transition-colors mb-4"
          >
            <ArrowRight className="w-5 h-5" />
            <span>العودة للنتيجة</span>
          </button>
          <h1 className="text-[#111827] mb-2">بدائل أفضل</h1>
          <p className="text-[#6B7280]">وجدنا لك منتجات بديلة بتقييم أعلى وسعر أفضل</p>
        </div>

        {/* Original Product Summary */}
        <div className="bg-gradient-to-br from-[#F3F4F6] to-white rounded-3xl p-6 mb-8 border-2 border-gray-200">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-xl bg-[#6B7280]/10 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4 text-[#6B7280]" />
            </div>
            <span className="text-[#6B7280]">المنتج الأصلي</span>
          </div>
          <div className="grid md:grid-cols-4 gap-4 items-center">
            <div className="flex items-center gap-3">
              <ImageWithFallback
                src={originalProduct.image}
                alt={originalProduct.name}
                className="w-16 h-16 rounded-2xl object-cover"
              />
              <div>
                <h3 className="text-[#111827]">{originalProduct.name}</h3>
                <p className="text-[#6B7280]">{originalProduct.platform}</p>
              </div>
            </div>
            <div className="text-center">
              <p className="text-[#6B7280] mb-1">السعر</p>
              <span className="text-[#111827]">{originalProduct.price}</span>
            </div>
            <div className="text-center">
              <p className="text-[#6B7280] mb-1">نسبة الثقة</p>
              <TrustBadge score={originalProduct.score} size="sm" />
            </div>
            <div className="text-center">
              <span className="text-[#6B7280]">3 بدائل أفضل →</span>
            </div>
          </div>
        </div>

        {/* Alternatives Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {alternatives.map((alt, index) => (
            <div
              key={alt.id}
              className="bg-white rounded-3xl shadow-sm border-2 border-gray-100 overflow-hidden hover:shadow-xl hover:border-[#3B82F6] transition-all group"
            >
              {/* Badge */}
              {index === 0 && (
                <div className="bg-gradient-to-r from-[#16A34A] to-[#15803D] text-white px-4 py-2 text-center">
                  <div className="flex items-center justify-center gap-2">
                    <TrendingUp className="w-4 h-4" />
                    <span>الأفضل من حيث القيمة</span>
                  </div>
                </div>
              )}

              <div className="p-6">
                {/* Image */}
                <div className="relative mb-4">
                  <ImageWithFallback
                    src={alt.image}
                    alt={alt.name}
                    className="w-full h-48 object-cover rounded-2xl"
                  />
                  <div className="absolute top-3 right-3">
                    <TrustBadge score={alt.score} size="sm" />
                  </div>
                  {alt.savings && (
                    <div className="absolute top-3 left-3 bg-[#DC2626] text-white px-3 py-1 rounded-full text-sm flex items-center gap-1">
                      <DollarSign className="w-3 h-3" />
                      <span>وفّر {alt.savings}</span>
                    </div>
                  )}
                </div>

                {/* Info */}
                <h3 className="text-[#111827] mb-2">{alt.name}</h3>
                <p className="text-[#6B7280] mb-4">{alt.platform}</p>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-[#F59E0B] text-[#F59E0B]" />
                    <span className="text-[#111827]">{alt.rating}</span>
                  </div>
                  <span className="text-[#6B7280]">({alt.reviews.toLocaleString()} تقييم)</span>
                </div>

                {/* Highlights */}
                <div className="space-y-2 mb-4">
                  {alt.highlights.map((highlight, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#3B82F6] mt-2 flex-shrink-0" />
                      <span className="text-[#6B7280]">{highlight}</span>
                    </div>
                  ))}
                </div>

                {/* Price */}
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-[#111827]">{alt.price}</span>
                  {alt.originalPrice && (
                    <span className="text-[#6B7280] line-through">{alt.originalPrice}</span>
                  )}
                </div>

                {/* Action Button */}
                <button className="w-full px-6 py-3 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white rounded-2xl hover:shadow-lg hover:shadow-blue-500/30 transition-all group-hover:scale-105">
                  عرض المنتج
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Why These Alternatives */}
        <div className="bg-gradient-to-br from-[#3B82F6]/5 to-[#8B5CF6]/5 rounded-3xl p-6 lg:p-8 mt-8">
          <h2 className="text-[#111827] mb-4">لماذا نوصي بهذه البدائل؟</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[#16A34A]/10 flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-6 h-6 text-[#16A34A]" />
              </div>
              <div>
                <h3 className="text-[#111827] mb-1">نسبة ثقة أعلى</h3>
                <p className="text-[#6B7280]">جميع البدائل حصلت على تقييمات أفضل من المنتج الأصلي</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[#3B82F6]/10 flex items-center justify-center flex-shrink-0">
                <DollarSign className="w-6 h-6 text-[#3B82F6]" />
              </div>
              <div>
                <h3 className="text-[#111827] mb-1">قيمة أفضل للسعر</h3>
                <p className="text-[#6B7280]">وفّر حتى 25€ مع الحصول على جودة أعلى</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[#8B5CF6]/10 flex items-center justify-center flex-shrink-0">
                <Star className="w-6 h-6 text-[#8B5CF6]" />
              </div>
              <div>
                <h3 className="text-[#111827] mb-1">تقييمات حقيقية</h3>
                <p className="text-[#6B7280]">منتجات بآلاف التقييمات الإيجابية الموثوقة</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[#F3F4F6]">
      <Sidebar
        currentPage="dashboard"
        onNavigate={onNavigate}
        onLogout={onLogout}
        isMobile={isMobile}
      />
      <div className="flex-1 overflow-auto">
        {content}
      </div>
    </div>
  );
}
