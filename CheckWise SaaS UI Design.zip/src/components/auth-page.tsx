import { Shield, Mail, Lock, Chrome } from 'lucide-react';
import { useState } from 'react';

interface AuthPageProps {
  onLogin: () => void;
  onNavigate: (page: string) => void;
}

export function AuthPage({ onLogin, onNavigate }: AuthPageProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#3B82F6]/10 via-[#8B5CF6]/10 to-[#F3F4F6] flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <span className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] bg-clip-text text-transparent">
              CheckWise
            </span>
          </div>
          <p className="text-[#6B7280]">افحص المنتج قبل الشراء بثقة</p>
        </div>

        {/* Auth Card */}
        <div className="bg-white rounded-3xl shadow-xl p-8">
          {/* Toggle Tabs */}
          <div className="flex gap-2 mb-8 bg-[#F3F4F6] rounded-2xl p-1">
            <button
              onClick={() => setIsLogin(true)}
              className={`flex-1 px-6 py-3 rounded-xl transition-all ${
                isLogin
                  ? 'bg-white shadow-sm text-[#111827]'
                  : 'text-[#6B7280]'
              }`}
            >
              تسجيل الدخول
            </button>
            <button
              onClick={() => setIsLogin(false)}
              className={`flex-1 px-6 py-3 rounded-xl transition-all ${
                !isLogin
                  ? 'bg-white shadow-sm text-[#111827]'
                  : 'text-[#6B7280]'
              }`}
            >
              إنشاء حساب
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email Field */}
            <div>
              <label htmlFor="email" className="block text-[#111827] mb-2">
                البريد الإلكتروني
              </label>
              <div className="relative">
                <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="w-full pr-12 pl-4 py-3 border-2 border-gray-200 rounded-2xl focus:border-[#3B82F6] focus:outline-none transition-colors text-right"
                  required
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <label htmlFor="password" className="block text-[#111827] mb-2">
                كلمة المرور
              </label>
              <div className="relative">
                <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pr-12 pl-4 py-3 border-2 border-gray-200 rounded-2xl focus:border-[#3B82F6] focus:outline-none transition-colors text-right"
                  required
                />
              </div>
            </div>

            {/* Forgot Password (Login only) */}
            {isLogin && (
              <div className="text-left">
                <a href="#" className="text-[#3B82F6] hover:underline">
                  نسيت كلمة المرور؟
                </a>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full px-6 py-4 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white rounded-2xl hover:shadow-lg hover:shadow-blue-500/30 transition-all"
            >
              {isLogin ? 'تسجيل الدخول' : 'إنشاء حساب'}
            </button>

            {/* Divider */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200"></div>
              </div>
              <div className="relative flex justify-center">
                <span className="bg-white px-4 text-[#6B7280]">أو</span>
              </div>
            </div>

            {/* Google Sign In */}
            <button
              type="button"
              className="w-full px-6 py-4 border-2 border-gray-200 rounded-2xl hover:bg-[#F3F4F6] transition-all flex items-center justify-center gap-3"
            >
              <Chrome className="w-5 h-5" />
              <span className="text-[#111827]">تسجيل باستخدام Google</span>
            </button>
          </form>

          {/* Terms */}
          {!isLogin && (
            <p className="text-center text-sm text-[#6B7280] mt-6">
              بإنشاء حساب، أنت توافق على{' '}
              <a href="#" className="text-[#3B82F6] hover:underline">
                الشروط والأحكام
              </a>{' '}
              و{' '}
              <a href="#" className="text-[#3B82F6] hover:underline">
                سياسة الخصوصية
              </a>
            </p>
          )}
        </div>

        {/* Back to Landing */}
        <div className="text-center mt-6">
          <button
            onClick={() => onNavigate('landing')}
            className="text-[#6B7280] hover:text-[#111827] transition-colors"
          >
            ← العودة إلى الصفحة الرئيسية
          </button>
        </div>
      </div>
    </div>
  );
}
