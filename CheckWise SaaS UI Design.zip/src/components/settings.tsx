import { Sidebar } from './ui-components/sidebar';
import { User, Globe, Bell, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';

interface SettingsProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
  isMobile: boolean;
}

export function Settings({ onNavigate, onLogout, isMobile }: SettingsProps) {
  const [name, setName] = useState('Bakri');
  const [email, setEmail] = useState('bakri@example.com');
  const [language, setLanguage] = useState('ar');
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(false);

  const handleSaveProfile = () => {
    toast.success('تم حفظ التغييرات بنجاح! ✅');
  };

  const handleToggleNotification = (type: string, value: boolean) => {
    if (value) {
      toast.success(`تم تفعيل ${type}`);
    } else {
      toast.info(`تم إيقاف ${type}`);
    }
  };

  const handleDeleteAccount = () => {
    toast.error('هل أنت متأكد؟ سيتم حذف جميع بياناتك!', {
      duration: 5000,
    });
  };

  const content = (
    <div className={`${isMobile ? 'pt-16 pb-20' : ''} p-4 lg:p-8`} dir="rtl">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-[#111827] mb-2">الإعدادات</h1>
          <p className="text-[#6B7280]">إدارة حسابك وتفضيلاتك</p>
        </div>

        {/* Profile Section */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 lg:p-8 mb-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-[#111827]">الملف الشخصي</h2>
          </div>

          <div className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-[#111827] mb-2">
                الاسم
              </label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-2xl focus:border-[#3B82F6] focus:outline-none transition-colors text-right"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-[#111827] mb-2">
                البريد الإلكتروني
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-2xl focus:border-[#3B82F6] focus:outline-none transition-colors text-right"
              />
            </div>

            <button
              onClick={handleSaveProfile}
              className="px-6 py-3 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white rounded-2xl hover:shadow-lg hover:shadow-blue-500/30 transition-all"
            >
              حفظ التغييرات
            </button>
          </div>
        </div>

        {/* Language Section */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 lg:p-8 mb-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-[#3B82F6]/10 flex items-center justify-center">
              <Globe className="w-6 h-6 text-[#3B82F6]" />
            </div>
            <h2 className="text-[#111827]">اللغة</h2>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-3 p-4 border-2 border-[#3B82F6] rounded-2xl bg-[#3B82F6]/5">
              <input
                type="radio"
                id="arabic"
                name="language"
                value="ar"
                checked={language === 'ar'}
                onChange={(e) => {
                  setLanguage(e.target.value);
                  toast.success('تم تغيير اللغة إلى العربية');
                }}
                className="w-5 h-5 text-[#3B82F6]"
              />
              <label htmlFor="arabic" className="flex-1 cursor-pointer text-[#111827]">
                العربية
              </label>
            </div>

            <div className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-2xl hover:border-[#3B82F6] transition-colors cursor-pointer">
              <input
                type="radio"
                id="english"
                name="language"
                value="en"
                checked={language === 'en'}
                onChange={(e) => {
                  setLanguage(e.target.value);
                  toast.success('Language changed to English');
                }}
                className="w-5 h-5 text-[#3B82F6]"
              />
              <label htmlFor="english" className="flex-1 cursor-pointer text-[#111827]">
                English
              </label>
            </div>
          </div>
        </div>

        {/* Notifications Section */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 lg:p-8 mb-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-[#3B82F6]/10 flex items-center justify-center">
              <Bell className="w-6 h-6 text-[#3B82F6]" />
            </div>
            <h2 className="text-[#111827]">التنبيهات</h2>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border-2 border-gray-200 rounded-2xl">
              <div>
                <h3 className="text-[#111827] mb-1">تنبيهات البريد الإلكتروني</h3>
                <p className="text-[#6B7280]">احصل على تنبيهات عبر البريد الإلكتروني</p>
              </div>
              <button
                onClick={() => {
                  const newValue = !emailNotifications;
                  setEmailNotifications(newValue);
                  handleToggleNotification('تنبيهات البريد الإلكتروني', newValue);
                }}
                className={`relative w-14 h-8 rounded-full transition-colors ${
                  emailNotifications ? 'bg-[#16A34A]' : 'bg-gray-300'
                }`}
              >
                <div
                  className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-transform ${
                    emailNotifications ? 'right-1' : 'right-7'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-4 border-2 border-gray-200 rounded-2xl">
              <div>
                <h3 className="text-[#111827] mb-1">إشعارات الدفع</h3>
                <p className="text-[#6B7280]">احصل على إشعارات فورية على جهازك</p>
              </div>
              <button
                onClick={() => {
                  const newValue = !pushNotifications;
                  setPushNotifications(newValue);
                  handleToggleNotification('إشعارات الدفع', newValue);
                }}
                className={`relative w-14 h-8 rounded-full transition-colors ${
                  pushNotifications ? 'bg-[#16A34A]' : 'bg-gray-300'
                }`}
              >
                <div
                  className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-transform ${
                    pushNotifications ? 'right-1' : 'right-7'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Account Management Section */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 lg:p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-[#DC2626]/10 flex items-center justify-center">
              <Trash2 className="w-6 h-6 text-[#DC2626]" />
            </div>
            <h2 className="text-[#111827]">إدارة الحساب</h2>
          </div>

          <div className="space-y-4">
            <p className="text-[#6B7280]">
              حذف حسابك سيؤدي إلى فقدان جميع بياناتك وفحوصاتك بشكل نهائي. هذا الإجراء لا يمكن التراجع عنه.
            </p>

            <button
              onClick={handleDeleteAccount}
              className="px-6 py-3 bg-[#DC2626] text-white rounded-2xl hover:bg-[#B91C1C] transition-all flex items-center gap-2"
            >
              <Trash2 className="w-5 h-5" />
              <span>حذف الحساب</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[#F3F4F6]">
      <Sidebar
        currentPage="settings"
        onNavigate={onNavigate}
        onLogout={onLogout}
        isMobile={isMobile}
      />
      <div className="flex-1 overflow-auto">
        {content}
      </div>
    </div>
  );
}