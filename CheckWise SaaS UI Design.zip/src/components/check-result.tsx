import { Sidebar } from './ui-components/sidebar';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Check, X, ThumbsUp, AlertTriangle, ShoppingBag, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

interface CheckResultProps {
  onNavigate: (page: string) => void;
  onLogout: () => void;
  isMobile: boolean;
}

export function CheckResult({ onNavigate, onLogout, isMobile }: CheckResultProps) {
  const score = 82;
  const product = {
    name: 'ساعة ذكية رياضية مقاومة للماء مع مراقبة معدل ضربات القلب',
    price: '29.99€',
    platform: 'Amazon',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30',
  };

  const pros = [
    'تقييمات إيجابية حقيقية (85% من المراجعات)',
    'سعر مناسب مقارنة بالمنافسين',
    'البائع موثوق مع تقييم عالي',
    'شحن سريع ومضمون',
    'ضمان الاسترجاع متاح',
  ];

  const cons = [
    'بعض الشكاوى حول عمر البطارية',
    'مشاكل في تطبيق الهاتف (15% من التقييمات)',
    'الشحن قد يتأخر في بعض المناطق',
  ];

  const getRecommendation = () => {
    if (score >= 70) {
      return {
        icon: ThumbsUp,
        color: 'text-[#16A34A]',
        bg: 'bg-[#16A34A]/10',
        message: 'ننصح بالشراء 👍',
        detail: 'هذا المنتج حصل على تقييم عالي ويبدو موثوقاً بناءً على تحليلنا للتقييمات والبيانات.',
      };
    } else if (score >= 40) {
      return {
        icon: AlertTriangle,
        color: 'text-[#F59E0B]',
        bg: 'bg-[#F59E0B]/10',
        message: 'يمكن الشراء لكن انتبه للنقاط التالية ⚠',
        detail: 'المنتج لديه بعض المشاكل المحتملة. راجع النقاط السلبية قبل اتخاذ القرار.',
      };
    } else {
      return {
        icon: X,
        color: 'text-[#DC2626]',
        bg: 'bg-[#DC2626]/10',
        message: 'لا ننصح بالشراء ❌',
        detail: 'هذا المنتج حصل على تقييم منخفض ويبدو أنه قد يكون غير موثوق.',
      };
    }
  };

  const recommendation = getRecommendation();
  const RecommendationIcon = recommendation.icon;

  const handleViewAlternatives = () => {
    toast.info('جاري البحث عن بدائل أفضل...');
    setTimeout(() => {
      onNavigate('alternatives');
    }, 500);
  };

  const content = (
    <div className={`${isMobile ? 'pt-16 pb-20' : ''} p-4 lg:p-8`} dir="rtl">
      <div className="max-w-5xl mx-auto">
        {/* Product Header */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 lg:p-8 mb-6">
          <div className="grid md:grid-cols-2 gap-6 lg:gap-8 items-start">
            <div className="flex flex-col items-center">
              <ImageWithFallback
                src={product.image}
                alt={product.name}
                className="w-full max-w-sm h-64 object-cover rounded-2xl mb-4"
              />
              <div className="flex items-center gap-2 text-[#6B7280]">
                <ShoppingBag className="w-4 h-4" />
                <span>{product.platform}</span>
              </div>
            </div>

            <div>
              <h1 className="text-[#111827] mb-4">{product.name}</h1>
              <div className="mb-6">
                <span className="text-[#111827]">{product.price}</span>
              </div>

              {/* Trust Score Circle */}
              <div className="flex items-center justify-center mb-6">
                <div className={`relative w-48 h-48 rounded-full ${
                  score >= 70 ? 'bg-[#16A34A]/10' : score >= 40 ? 'bg-[#F59E0B]/10' : 'bg-[#DC2626]/10'
                } flex items-center justify-center`}>
                  <div className="text-center">
                    <p className="text-[#6B7280] mb-2">نسبة الثقة</p>
                    <span className={`${
                      score >= 70 ? 'text-[#16A34A]' : score >= 40 ? 'text-[#F59E0B]' : 'text-[#DC2626]'
                    }`}>
                      {score}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Pros & Cons */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {/* Pros */}
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-[#16A34A]/10 flex items-center justify-center">
                <Check className="w-5 h-5 text-[#16A34A]" />
              </div>
              <h2 className="text-[#111827]">نقاط إيجابية</h2>
            </div>
            <ul className="space-y-3">
              {pros.map((pro, index) => (
                <li key={index} className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#16A34A] flex-shrink-0 mt-0.5" />
                  <span className="text-[#6B7280]">{pro}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Cons */}
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-[#F59E0B]/10 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-[#F59E0B]" />
              </div>
              <h2 className="text-[#111827]">نقاط سلبية متكررة</h2>
            </div>
            <ul className="space-y-3">
              {cons.map((con, index) => (
                <li key={index} className="flex items-start gap-3">
                  <X className="w-5 h-5 text-[#F59E0B] flex-shrink-0 mt-0.5" />
                  <span className="text-[#6B7280]">{con}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Recommendation */}
        <div className={`${recommendation.bg} rounded-3xl p-6 lg:p-8 mb-6`}>
          <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
            <div className={`w-16 h-16 rounded-2xl ${recommendation.bg} flex items-center justify-center flex-shrink-0`}>
              <RecommendationIcon className={`w-8 h-8 ${recommendation.color}`} />
            </div>
            <div className="flex-1">
              <h2 className={`${recommendation.color} mb-2`}>{recommendation.message}</h2>
              <p className="text-[#6B7280]">{recommendation.detail}</p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid md:grid-cols-2 gap-4">
          <button 
            onClick={handleViewAlternatives}
            className="px-6 py-4 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white rounded-2xl hover:shadow-xl hover:shadow-blue-500/30 transition-all flex items-center justify-center gap-2">
            <span>شاهد بدائل أفضل</span>
            <ArrowRight className="w-5 h-5" />
          </button>
          <button
            onClick={() => onNavigate('history')}
            className="px-6 py-4 border-2 border-gray-200 text-[#6B7280] rounded-2xl hover:bg-[#F3F4F6] transition-all"
          >
            رجوع إلى السجل
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[#F3F4F6]">
      <Sidebar
        currentPage="dashboard"
        onNavigate={onNavigate}
        onLogout={onLogout}
        isMobile={isMobile}
      />
      <div className="flex-1 overflow-auto">
        {content}
      </div>
    </div>
  );
}