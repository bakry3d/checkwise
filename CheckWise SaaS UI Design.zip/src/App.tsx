import { useState } from 'react';
import { LandingPage } from './components/landing-page';
import { AuthPage } from './components/auth-page';
import { Dashboard } from './components/dashboard';
import { NewCheck } from './components/new-check';
import { CheckResult } from './components/check-result';
import { History } from './components/history';
import { CreditsPlans } from './components/credits-plans';
import { Settings } from './components/settings';
import { Alternatives } from './components/alternatives';
import { Toaster } from 'sonner@2.0.3';

type Page = 'landing' | 'auth' | 'dashboard' | 'new-check' | 'check-result' | 'history' | 'credits' | 'settings' | 'alternatives';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  // Handle responsive
  useState(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  });

  const handleLogin = () => {
    setIsLoggedIn(true);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentPage('landing');
  };

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage onNavigate={navigateTo} />;
      case 'auth':
        return <AuthPage onLogin={handleLogin} onNavigate={navigateTo} />;
      case 'dashboard':
        return <Dashboard onNavigate={navigateTo} onLogout={handleLogout} isMobile={isMobile} />;
      case 'new-check':
        return <NewCheck onNavigate={navigateTo} onLogout={handleLogout} isMobile={isMobile} />;
      case 'check-result':
        return <CheckResult onNavigate={navigateTo} onLogout={handleLogout} isMobile={isMobile} />;
      case 'history':
        return <History onNavigate={navigateTo} onLogout={handleLogout} isMobile={isMobile} />;
      case 'credits':
        return <CreditsPlans onNavigate={navigateTo} onLogout={handleLogout} isMobile={isMobile} />;
      case 'settings':
        return <Settings onNavigate={navigateTo} onLogout={handleLogout} isMobile={isMobile} />;
      case 'alternatives':
        return <Alternatives onNavigate={navigateTo} onLogout={handleLogout} isMobile={isMobile} />;
      default:
        return <LandingPage onNavigate={navigateTo} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F3F4F6]">
      <Toaster position="top-center" dir="rtl" richColors />
      {renderPage()}
    </div>
  );
}